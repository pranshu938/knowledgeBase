const express = require("express");
const checkAuth = require("../middleware/auth.middleware");
const { createNote, getNotes } = require("../controllers/notes.conroller");

const router = express.Router();

// Create note
router.post("/", checkAuth, createNote);

// List notes (current user only)
router.get("/", checkAuth, getNotes);

module.exports = router;
