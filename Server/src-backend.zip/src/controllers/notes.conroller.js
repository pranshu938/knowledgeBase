const Note = require("../models/note.model");

const createNote = async (req, res) => {
  const { title, content = "", tags = [] } = req.body;

  const note = await Note.create({
    userId: req.user.userId,
    title,
    content,
    tags,
  });

  res.status(201).json({ note });
};

const getNotes = async (req, res) => {
  const notes = await Note.find({ userId: req.user.userId })
    .sort({ updatedAt: -1 })
    .lean();

  res.json({ notes });
};

module.exports = {
  createNote,
  getNotes,
};
