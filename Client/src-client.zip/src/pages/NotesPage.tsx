export default function NotesPage() {
  // UI-only dummy data for now (replace with API later)
  const notes = [
    {
      id: "1",
      title: "Insurance Claim Notes",
      updatedText: "Updated 3h ago",
      tags: ["work", "claim", "api"],
      preview:
        "Policy renewal steps, premium breakdown, and common edge cases…",
    },
    {
      id: "2",
      title: "AI Ideas",
      updatedText: "Updated 2d ago",
      tags: ["ai", "kb"],
      preview:
        "Upload PDFs → extract text → embeddings → chat with knowledge base…",
    },
  ];

  return (
    <div className="notes-page">
      {/* Header */}
      <div className="notes-header">
        <div>
          <h1 className="notes-title">Notes</h1>
          <p className="notes-subtitle">Your notes and uploads in one place.</p>
        </div>

        <div className="notes-header-actions">
          <button className="btn btn-primary">+ New Note</button>
        </div>
      </div>

      {/* Controls */}
      <div className="notes-controls">
        <div className="notes-controls-left">
          <div className="notes-control">
            <label className="notes-label">Sort</label>
            <select className="notes-select">
              <option>Updated</option>
              <option>Created</option>
              <option>Title</option>
            </select>
          </div>

          <div className="notes-control">
            <label className="notes-label">Tag</label>
            <select className="notes-select">
              <option>All</option>
              <option>work</option>
              <option>ai</option>
              <option>claim</option>
            </select>
          </div>
        </div>

        <div className="notes-controls-right">
          <input
            className="notes-search"
            placeholder="Search notes…"
            aria-label="Search notes"
          />
        </div>
      </div>

      {/* List */}
      <div className="notes-grid">
        {notes.map((n) => (
          <article key={n.id} className="note-card">
            <div className="note-card-top">
              <div className="note-card-main">
                <h3 className="note-title">{n.title}</h3>
                <div className="note-meta">{n.updatedText}</div>
              </div>

              <div className="note-actions">
                <button className="btn btn-ghost">Edit</button>
                <button className="btn btn-danger-ghost">Delete</button>
              </div>
            </div>

            <p className="note-preview">{n.preview}</p>

            <div className="note-tags">
              {n.tags.map((t) => (
                <span key={t} className="tag-chip">
                  {t}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>

      {/* Empty state (use when notes.length === 0) */}
      {/* 
      <div className="notes-empty">
        <div className="notes-empty-card">
          <h3>No notes yet</h3>
          <p>Create your first note to get started.</p>
          <button className="btn btn-primary">+ Create Note</button>
        </div>
      </div>
      */}
    </div>
  );
}
