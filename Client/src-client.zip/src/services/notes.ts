import api from "../lib/api";

export type Note = {
  _id?: string;
  title?: string;
  content?: string;
  tags?: string[];
  updatedAt?: string;
  createdAt?: string;
};

export const createNote = async(payload:Note)=>{
    try{
    
    }catch(){

    }
}
